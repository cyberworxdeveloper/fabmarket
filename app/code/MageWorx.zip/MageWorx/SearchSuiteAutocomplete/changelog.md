## Changelog

### Version 2.1.4

- **Fix**: Update locale file