<?php namespace Codazon\MegaMenu\Block\Adminhtml\Index\Edit\Fieldset;
class MenuItems extends \Magento\Backend\Block\Widget\Form\Renderer\Fieldset{

}
?>