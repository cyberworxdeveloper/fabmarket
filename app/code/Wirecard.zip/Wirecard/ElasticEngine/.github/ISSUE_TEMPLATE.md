### Prerequisites

- [ ] I have my [server set up correctly](https://github.com/wirecard/magento2-ee/wiki/Installation#requirements).
- [ ] I am using a [supported version of Magento](https://github.com/wirecard/magento2-ee/wiki#overview-magento-2-shop-plugin).

### Versions

**Magento version:** ...  
**PHP version:** ...  

### Issue

**Problem description:**

...


**Steps to reproduce:**

...
