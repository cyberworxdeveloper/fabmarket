var config = {
    paths: {
        'owlcarousel': 'Vgroup65_Testimonial/js/owlcarousel'
    },
    shim: {
        'owlcarousel': {
            deps: ['jquery']
        }
    }
};