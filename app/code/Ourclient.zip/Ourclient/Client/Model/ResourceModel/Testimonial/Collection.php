<?php
namespace Ourclient\Client\Model\ResourceModel\Client;
 
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'Client_id';
    /**
     * Define resource model.
     */
    protected function _construct()
    {
        $this->_init('Ourclient\Client\Model\Client', 'Ourclient\Client\Model\ResourceModel\Client');
    }
}