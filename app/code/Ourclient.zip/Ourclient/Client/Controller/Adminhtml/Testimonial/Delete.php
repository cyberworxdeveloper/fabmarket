<?php
namespace Ourclient\Client\Controller\Adminhtml\Client;
 
use Ourclient\Client\Controller\Adminhtml\Client;
 
class Delete extends Client
{
   /**
    * @return void
    */
   public function execute()
   {
      $ClientId = (int) $this->getRequest()->getParam('id');
      $helper = $this->helper;
      
      if (isset($ClientId)) {
         /** @var $newsModel \Mageworld\SimpleNews\Model\News */
         $ClientModel = $this->_ClientFactory->create();
         $ClientModel->load($ClientId);
 
         // Check this news exists or not
         if (!$ClientModel->getId()) {
            $this->messageManager->addError(__('This Client no longer exists.'));
         } else {
               try {
                $ClientData = $ClientModel->getData();

                if(!empty($ClientData['image'])):
                    $currentImage = $ClientData['image'];
                    if (!filter_var($currentImage, FILTER_VALIDATE_URL)):
                         if (file_exists($helper->getBaseDir().$currentImage)):
                            unlink($helper->getBaseDir().$currentImage); 
                         endif; 
                    endif;               
                endif; 
                
                if(!empty($ClientData['resize_image'])):
                    $currentResizeImage = $ClientData['resize_image'];
                    if (!filter_var($currentResizeImage, FILTER_VALIDATE_URL)):
                         if (file_exists($helper->getBaseDir().$currentResizeImage)):
                            unlink($helper->getBaseDir().$currentResizeImage); 
                         endif; 
                    endif;               
                endif; 
                   
                  // Delete news
                  $ClientModel->delete();
                  $this->messageManager->addSuccess(__('The Client has been deleted.'));
 
                  // Redirect to grid page
                  $this->_redirect('*/*/');
                  return;
               } catch (\Exception $e) {
                   $this->messageManager->addError($e->getMessage());
                   $this->_redirect('*/*/edit', ['id' => $ClientModel->getId()]);
               }
            }
      }
   }
   
}
 