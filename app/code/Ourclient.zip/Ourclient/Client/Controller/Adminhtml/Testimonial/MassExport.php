<?php
namespace Ourclient\Client\Controller\Adminhtml\Client;

use Magento\Framework\Controller\ResultFactory;
use Magento\Backend\App\Action\Context;
use Magento\Ui\Component\MassAction\Filter;
use Ourclient\Client\Helper\Data;
use Ourclient\Client\Model\ResourceModel\Client\CollectionFactory;

class MassExport extends \Magento\Backend\App\Action {
    
    /**
     * Massactions filter.?_
     * @var Filter
     */
    protected $_filter;
    
    protected $helper;

    /**
     * @var CollectionFactory
     */
    protected $_collectionFactory;

    /**
     * @param Context           $context
     * @param Filter            $filter
     * @param CollectionFactory $collectionFactory
     */
    public function __construct(
    Context $context, Filter $filter, CollectionFactory $collectionFactory, Data $helper
    ) {
        $this->_filter = $filter;
        $this->_collectionFactory = $collectionFactory;
        $this->helper = $helper;
        parent::__construct($context);
    }

    /**
     * @return void
     */
    public function execute() {
        $collection = $this->_filter->getCollection($this->_collectionFactory->create());

        /* @var Ourclient\News\Helper\Data */
        $imageHelper = $this->helper;
        $basePath = $imageHelper->getBaseDir();

        $heading = [
            __('Client ID'),
            __('Title'),
            __('Status')
        ];
        $outputFile = $basePath . "/ClientList.csv";
        $handle = fopen($outputFile, 'w');
        fputcsv($handle, $heading);
        foreach ($collection->getItems() as $Client) {

            //status
            $status = 'Disabled';
            if ($Client->getData('status') == '1'):
                $status = 'Enabled';
            endif;

            //image 
            $ClientImageValue = '';
            $ClientImage = $Client->getData('image');
            if (!empty($ClientImage)):
                if (!filter_var($ClientImage, FILTER_VALIDATE_URL)):
                    $getBaseUrl = $imageHelper->getBaseUrl();
                    $ClientImageValue = $getBaseUrl . $ClientImage;
                endif;
            endif;

            $row = [
                $Client->getData('Client_id'),
                $Client->getData('first_name'),
                $status
            ];
            fputcsv($handle, $row);
        }
        $this->downloadCsv($outputFile);
    }

    public function downloadCsv($file) {
        if (file_exists($file)) {
            //set appropriate headers
            header('Content-Description: File Transfer');
            header('Content-Type: application/csv');
            header('Content-Disposition: attachment; filename=' . basename($file));
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($file));
            ob_clean();
            flush();
            readfile($file);
            unlink($file);
        }
    }

}
