<?php
namespace Ourclient\Client\Controller\Adminhtml\Client;

use Ourclient\Client\Controller\Adminhtml\Client;
class NewAction extends Client {

    public function execute(){
        $this->_forward('edit');
    }
    
}
