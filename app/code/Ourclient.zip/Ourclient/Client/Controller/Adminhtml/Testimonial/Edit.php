<?php
namespace Ourclient\Client\Controller\Adminhtml\Client;
use Ourclient\Client\Controller\Adminhtml\Client;

class Edit extends Client{

    public function execute(){
        $newsId = $this->getRequest()->getParam('id');
        
        $model = $this->_ClientFactory->create();
        if($newsId){
            $model->load($newsId);
            if(!$model->getId()){
                $this->_messageManager->addError('This id is no longer exist');
                $this->_redirect('*/*/');
                return;
            }   
        }
        
        $this->_coreRegistry->register('vgroup_Client', $model);
        
        $resultPage = $this->_resultPageFactory->create();
        $resultPage->setActiveMenu('Ourclient_Client::main_menu');
        $resultPage->getConfig()->getTitle()->prepend(__(($newsId)?'Edit Client':'Add Client'));
        return $resultPage;
        
    }
    
}