<?php
namespace Ourclient\Client\Controller\Adminhtml;

use Magento\Backend\App\Action\Context;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Ourclient\Client\Model\ClientFactory;
use Ourclient\Client\Helper\Data;
use Magento\Framework\Image\AdapterFactory;

abstract class Client extends \Magento\Backend\App\Action
{
    protected $_coreRegistry;

    protected $_resultPageFactory;

    protected $_ClientFactory;
    
    protected $helper;
    
    protected $_imageFactory;

    public function __construct(
        Context $context,
        Registry $coreRegistry,
        PageFactory $resultPageFactory,
        ClientFactory $ClientFactory,
        Data $helper,
        AdapterFactory $imageFactory
    ) {
        parent::__construct($context);
        $this->_coreRegistry = $coreRegistry;
        $this->_resultPageFactory = $resultPageFactory;
        $this->_ClientFactory = $ClientFactory;
        $this->helper = $helper;
        $this->_imageFactory = $imageFactory;
    }
 
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Ourclient_Client::manage_Client');
    }
}