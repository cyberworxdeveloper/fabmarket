<?php
namespace Ourclient\Client\Controller\Adminhtml\Export;

use Ourclient\Client\Controller\Adminhtml\Client;
class Index extends Client {

    public function execute() {
        $ClientCollection = $this->_ClientFactory->create()->getCollection();
        $helper = $this->helper;
        $basePath = $helper->getBaseDir();

        $heading = [
            __('Client ID'),
            __('Title'),
            __('Status')
        ];
        
        if (!file_exists($basePath)):
             mkdir($basePath,0775, true);
        endif;
         
        $outputFile = $basePath."/ClientList.csv";
        $handle = fopen($outputFile, 'w');
        fputcsv($handle, $heading); 
        foreach ($ClientCollection as $Client) {
             //status
            $status = 'Disabled';
             if($Client['status'] == '1'):
                 $status = 'Enabled';
             endif;
             
             //image 
            $ClientImageValue = '';
            $ClientImage = $Client['image'];
            if(!empty($ClientImage)):
                    $getBaseUrl = $helper->getBaseUrl();
                    $ClientImageValue = $getBaseUrl.$ClientImage; 
            endif;    
             
             
             $row = [
                $Client['Client_id'],
                $Client['first_name'],
                $status
             ];
             fputcsv($handle, $row);
         }
         $this->downloadCsv($outputFile);
    }
 
    public function downloadCsv($file)
    {
         if (file_exists($file)) {
             //set appropriate headers
             header('Content-Description: File Transfer');
             header('Content-Type: application/csv');
             header('Content-Disposition: attachment; filename='.basename($file));
             header('Expires: 0');
             header('Cache-Control: must-revalidate');
             header('Pragma: public');
             header('Content-Length: ' . filesize($file));
             ob_clean();flush();
             readfile($file);
             unlink($file);
         }
    }
}