var config = {
    paths: {
        'owlcarousel': 'Ourclient_Client/js/owlcarousel'
    },
    shim: {
        'owlcarousel': {
            deps: ['jquery']
        }
    }
};