<?php
namespace Ourclient\Client\Block\Adminhtml;
use Magento\Backend\Block\Widget\Grid\Container;
class Client extends Container
{
   protected function _construct()
    {
        $this->_controller = 'adminhtml_Client';
        $this->_blockGroup = 'Ourclient_Client';
        $this->_headerText = __('Client list');
        $this->_addButtonLabel = __('Add New');
        parent::_construct();
    }
}