<?php
namespace Ourclient\Client\Block\Adminhtml\Helper\Image;
class Required extends \Magento\Framework\Data\Form\Element\Image
{
    
    
    protected function _getUrl()
    {
        if (!filter_var($this->getValue(), FILTER_VALIDATE_URL)):
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $helper = $objectManager->create('Ourclient\Client\Helper\Data');
            
            if(!empty($this->getValue())):
                return $helper->getBaseUrl().$this->getValue();
            endif;
            
            else:
            return $this->getValue();
        endif;
        
    }
}