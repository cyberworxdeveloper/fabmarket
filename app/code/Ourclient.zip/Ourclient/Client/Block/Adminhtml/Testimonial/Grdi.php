<?php
namespace Ourclient\Client\Block\Adminhtml\Client;
 
use Magento\Backend\Block\Widget\Grid as WidgetGrid;
class Grid extends WidgetGrid
{
   
}