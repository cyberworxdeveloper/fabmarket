<?php
namespace Ourclient\Client\Block;

class Client extends \Magento\Framework\View\Element\Template {

    protected $_pageSize = 10;
    protected $_Client;
//    protected $_configuration;
    protected $helper;
    
    public function __construct(\Magento\Framework\View\Element\Template\Context $context, \Ourclient\Client\Model\ClientFactory $ClientFactory, \Ourclient\Client\Helper\Data $helper
                              ) {
        parent::__construct($context);
        $this->_Client = $ClientFactory;
//        $this->_configuration = $configurationFactory;
        $this->helper = $helper;
    }
    
    public function getHelper(){
        return $this->helper;
    }

    protected function _prepareLayout() {
        $topMenuText = $this->helper->getConfig('configuration/top_navigation_menu_text');
        
        $breadcrumbs = $this->getLayout()->getBlock('breadcrumbs');
        $breadcrumbs->addCrumb('home', array('label'=>__('Home'), 'title'=>__('Home'), 'link'=> $this->getUrl()));
        $breadcrumbs->addCrumb($topMenuText, array('label'=>__($topMenuText), 'title'=> __($topMenuText), 'link'=>$this->getUrl('Client/')));
        $this->getLayout()->getBlock('breadcrumbs')->toHtml();
        $this->pageConfig->getTitle()->set(__($topMenuText));
        
        parent::_prepareLayout();
       
        //get news count
        $ClientListCount = $this->getClientListCount()->count();
        $defaultLimit = array(6 => 6);
         
        if($ClientListCount > 6 && $ClientListCount <= 10){
            $defaultLimit = array(6 => 6 , 10 => 10);            
        }
        if($ClientListCount > 10 && $ClientListCount <= 15){
            $defaultLimit = array(6 => 6 , 10 => 10 , 15 => 15);
        }
        if($ClientListCount > 15 && $ClientListCount <= 25){
            $defaultLimit = array(6 => 6 , 10 => 10 , 15 => 15 , 20 => 20);
        }
        if($ClientListCount > 25 && $ClientListCount <= 50){
            $defaultLimit = array(6 => 6 , 10 => 10 , 15 => 15 , 20 => 20 , 50 => 50);
        }
        if($ClientListCount > 50 && $ClientListCount <= 100){
            $defaultLimit = array(6 => 6 , 10 => 10 , 15 => 15 , 20 => 20 , 50 => 50 , 100 => 100);
        }
        
        
        if ($this->getClientList()) {
            $pager = $this->getLayout()->createBlock(
                            'Magento\Theme\Block\Html\Pager', 'fme.Client.pager'
                    )->setAvailableLimit($defaultLimit)->setShowPerPage(true)->setCollection($this->getClientList());
            $this->setChild('Client', $pager);
            $this->getClientList()->load();
        }
        return $this;
    }

    public function getPagerHtml() {
        return $this->getChildHtml('Client');
    }

    public function getClientList() {
        $page=($this->getRequest()->getParam('p'))? $this->getRequest()->getParam('p') : 1;
        //get values of current limit
        $pageSize=($this->getRequest()->getParam('limit'))? $this->getRequest()->getParam('limit') : 6;
        $ClientList = $this->_Client->create();
        $ClientCollection = $ClientList->getCollection();
        $ClientCollection->addFieldToFilter('status' , '1');
        $ClientCollection->setOrder('Client_id', 'DESC');
        $ClientCollection->setPageSize($pageSize);
        $ClientCollection->setCurPage($page);
        return $ClientCollection;
    }
    
    public function getClientListCount() {
        $ClientList = $this->_Client->create();
        $ClientCollection = $ClientList->getCollection();
        $ClientCollection->addFieldToFilter('status' , '1');
        $ClientCollection->setOrder('Client_id', 'DESC');
        return $ClientCollection;
    }
    
    public function getDisplayType() {
        $displayType = $this->helper->getConfig('configuration/display_type');
        return $displayType;
    }
    
    public function getTopMenuLink() {
        $menuText = $this->helper->getConfig('configuration/top_navigation_menu_text');
        return $menuText;
    }



}
