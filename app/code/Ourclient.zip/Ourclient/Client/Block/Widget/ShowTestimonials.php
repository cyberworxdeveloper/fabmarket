<?php
namespace Ourclient\Client\Block\Widget;

use Magento\Widget\Block\BlockInterface;
use Magento\Framework\View\Element\Template\Context;
use Ourclient\Client\Helper\Data; 
class ShowClients extends \Magento\Framework\View\Element\Template implements BlockInterface {

    protected $_template = 'widget/Client.phtml';
    protected $_Client;
//    protected $_configuration;
    protected $helper;
    public function __construct(Context $context , \Ourclient\Client\Model\ClientFactory $ClientFactory, \Ourclient\Client\Helper\Data $helper) {
        parent::__construct($context);
        $this->_Client = $ClientFactory;
//        $this->_configuration = $configurationFactory;
        $this->helper = $helper;
    }
    
    public function getClientList() {
        //get Client configuration count
        $ClientCount = $this->getConfigurationClientCount();
        if($ClientCount == 0):
            return array('status' => '0');
        endif;
        
        $ClientList = $this->_Client->create();
        $ClientCollection = $ClientList->getCollection();
        $ClientCollection->addFieldToFilter('status' , '1');
        $ClientCollection->setOrder('Client_id', 'DESC');
 
        $ClientCollection->setPageSize($ClientCount);
        return array('status' => '1' , 'Clients' => $ClientCollection);
    }
    
    public function getConfigurationClientCount() {
//        $ClientConfiguration = $this->_configuration->create();
//        $ClientCollection = $ClientConfiguration->getCollection();
//        $ClientCollection->addFieldToFilter('configuration_id', '1');
//        foreach($ClientCollection as $values):
//                $noOfClient = $values->getNoOfClient();
//        endforeach;
        $noOfClient = $this->helper->getConfig('configuration/no_of_display');
        return $noOfClient;
    }
    
    public function getClientConfiguration() {
//        $ClientConfiguration = $this->_configuration->create();
//        $ClientCollection = $ClientConfiguration->getCollection();
//        $ClientCollection->addFieldToFilter('configuration_id', '1');
//        foreach($ClientCollection as $values):
//                return $values->getTopMenuLink();
//        endforeach;
        $top_menu = $this->helper->getConfig('configuration/top_navigation_menu_text');
        return $top_menu;
    }
    
    public function getWidgetAutoRotate() {
//        $ClientConfiguration = $this->_configuration->create();
//        $ClientCollection = $ClientConfiguration->getCollection();
//        $ClientCollection->addFieldToFilter('configuration_id', '1');
//        foreach($ClientCollection as $values):
//                return $values->getAutoRotate();
//        endforeach;
        $auto_rotate = $this->helper->getConfig('configuration/auto_rotation');
        return $auto_rotate;
        
    }
    
    public function getBaseUrl(){
        return $this->helper->getBaseUrl();
    }
    
}