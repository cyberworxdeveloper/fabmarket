<?php
namespace Ourclient\Client\Block;
class Description extends \Magento\Framework\View\Element\Template
{
    protected $_Client;
    protected $helper;
//    protected $_configuration;
    
    public function __construct(\Magento\Framework\View\Element\Template\Context $context, \Ourclient\Client\Model\ClientFactory $ClientFactory, \Ourclient\Client\Helper\Data $helper
                              ) {
        parent::__construct($context);
        $this->_Client = $ClientFactory;
        $this->helper = $helper;
//        $this->_configuration = $configurationFactory;
    }
    
    protected function _prepareLayout() { 
        $topMenuText = $this->helper->getConfig('configuration/top_menu_link');
        $breadcrumbs = $this->getLayout()->getBlock('breadcrumbs');
        $breadcrumbs->addCrumb('home', array('label'=>__('Home'), 'title'=>__('Home'), 'link'=> $this->getUrl()));
        $breadcrumbs->addCrumb($topMenuText, array('label'=>$topMenuText, 'title'=> __($topMenuText), 'link'=>$this->getUrl('Client/')));
        
        //get Client
        $getClientDetails = $this->getClientDetails();
        foreach($getClientDetails as $ClientDetails):
            $ClientName = $ClientDetails['first_name'] . " " . $ClientDetails['last_name']; 
            $ClientId = $ClientDetails['Client_id'];
        endforeach;
        
        if(!empty($ClientId)):
        $breadcrumbs->addCrumb($ClientName, array('label'=>__($ClientName), 'title'=> __($topMenuText), 'link'=>$this->getUrl('Client/view/detail/', array('Client'=> $ClientId))));
        endif;
        $this->getLayout()->getBlock('breadcrumbs')->toHtml();
        $this->pageConfig->getTitle()->set(__($topMenuText));

        parent::_prepareLayout();
    }

    public function getClientDetails() {
        //get values of current limit
        $getParam = $this->getRequest()->getParam('Client');
        $ClientId = $this->getRequest()->getParam('Client');
        $ClientList = $this->_Client->create();
        $ClientCollection = $ClientList->getCollection();
        $ClientCollection->addFieldToFilter('Client_id' , $getParam);
        return $ClientCollection;
    }
    
    public function getHelper(){
        return $this->helper;
    }
    
}
