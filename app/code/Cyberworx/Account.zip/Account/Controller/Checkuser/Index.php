<?php
namespace Cyberworx\Account\Controller\Checkuser;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Index extends \Magento\Framework\App\Action\Action
{
protected $resultPageFactory;

protected $session;
protected $_connection;
public function __construct(
    \Magento\Framework\App\Action\Context $context,
    \Magento\Customer\Model\Session $customerSession,
    PageFactory $resultPageFactory
    )
{
    $this->session = $customerSession;
    parent::__construct($context);
    $this->resultPageFactory = $resultPageFactory;
    $this->_resources = \Magento\Framework\App\ObjectManager::getInstance()
->get('Magento\Framework\App\ResourceConnection');

}



public function execute()
{
 $email=$_GET['email'];
 $connection= $this->_resources->getConnection();
 $selectno = "select * from mg_customer_entity where email='$email'";
 $all_results = $connection->fetchAll($selectno); 

  $all_resultss=count($all_results);
if($all_resultss =='0'){
 echo 'User Not Registe';
 }   
}

}

